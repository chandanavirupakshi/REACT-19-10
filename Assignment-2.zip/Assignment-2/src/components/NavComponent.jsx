import './css/NavComponent.css';

function NavComponent(props) {
    return (
        <div className="nav">
        <div className="items">Navigation</div>
        <div className="items"></div>
        <div className="items"></div>
        <div className="items"></div>
      </div>
    );
}

export default NavComponent;