import './css/HeaderComponent.css';
function HeaderComponent(props) {
    return (
        <div className='header'>Header</div>
    );
}

export default HeaderComponent;