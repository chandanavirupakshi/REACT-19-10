import './css/FooterComponent.css';
function FooterComponent(props) {
    return(
        <div className="footer">Footer</div>
    );
}

export default FooterComponent;