import './App.css';
import './Components/LoginComponent';
import './Components/LoginComponent.css';
import './Components/LoginWithClassComponent';
import'./Components/LoginWithClassComponent.css';
import'./Components/TableComponent';
import'./Components/TableWithClassComponent';
import LoginComponent from './Components/LoginComponent';
import LoginWithClassComponent from './Components/LoginWithClassComponent';
import TableComponent from './Components/TableComponent';
import TableWithClassComponent from './Components/TableWithClassComponent';
function App() {
  var books = [
    {
    Id:"B-001",
    Name:"A",
    Author:"anitkar",
    Publication:"World-pub"
   },
   {
    Id:"B-002",
    Name:"A",
    Author:"anitkar",
    Publication:"World-pub"
   },
   {
    Id:"B-003",
    Name:"A",
    Author:"anitkar",
    Publication:"World-pub"
   },
   {
    Id:"B-004",
    Name:"A",
    Author:"anitkar",
    Publication:"World-pub"
   }];
  return (
    
    <div className="App">
       <LoginComponent></LoginComponent>
       <LoginWithClassComponent></LoginWithClassComponent>
       <TableComponent></TableComponent>
       <TableWithClassComponent></TableWithClassComponent>
    </div>
  );
 
}

export default App;
