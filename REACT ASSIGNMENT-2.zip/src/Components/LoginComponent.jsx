import './LoginComponent.css';
function LoginComponent(){
    return(
        <div className='form1'>
<form><h2>SIGN UP PAGE</h2>
<h3>Get Access to your orders and chat for support.</h3>
    <input type="text" placeholder="enter Your name"/><br /><br />
     <input type="text" placeholder="password"/><br /><br />
     <input type="submit" id='button' nvalue="Sign In"/>
</form>
</div>
    );
}

export default LoginComponent;