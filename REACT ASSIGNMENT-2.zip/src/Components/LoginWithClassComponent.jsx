import React from "react";
import { render } from "react-dom";

class LoginWithClassComponent extends React.Component{
    render(){
      return(
        <div className="form2">
        <form><h2>SIGN UP PAGE</h2>
      <h3>Get Access to your orders and chat for support.</h3>
     <input type="text" placeholder="enter Your name"/><br /><br />
     <input type="text" placeholder="password"/><br /><br />
     <input type="submit" id='button' nvalue="Sign In"/>
      </form>
      </div>);
    }
}
export default LoginWithClassComponent;